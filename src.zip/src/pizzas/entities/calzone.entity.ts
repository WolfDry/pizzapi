import { Entity, PrimaryGeneratedColumn, Column, Index, OneToOne, OneToMany, ManyToMany, JoinTable } from "typeorm"

import { ApiProperty } from "@nestjs/swagger";

@Entity()
export class Calzone {
    @ApiProperty()
    @PrimaryGeneratedColumn()
    id!: number;
}
