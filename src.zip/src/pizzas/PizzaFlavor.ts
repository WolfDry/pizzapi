export enum PizzaFlavor{
    Tomatoes = "T",
    Crema = "C",
}